# GitHub push notes

This local website folder already contains a Git repository and commit history.

Before submission:
1. Create a new private GitHub repository.
2. Add the remote URL.
3. Push the `main` branch.
4. Grant access to `matraversdavid` as requested in the brief.

Example commands:

```bash
git remote add origin <your-private-repo-url>
git push -u origin main
```
