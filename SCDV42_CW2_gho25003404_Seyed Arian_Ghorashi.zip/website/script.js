const root = document.documentElement;
const navToggle = document.querySelector('.nav-toggle');
const siteNav = document.querySelector('.site-nav');
const themeToggle = document.getElementById('theme-toggle');
const fontSmaller = document.getElementById('font-smaller');
const fontReset = document.getElementById('font-reset');
const fontLarger = document.getElementById('font-larger');
const filterButtons = document.querySelectorAll('.filter-btn');
const sessionCards = document.querySelectorAll('.session-card');
const contactForm = document.getElementById('contact-form');
const feedback = document.getElementById('form-feedback');

const STORAGE_KEYS = {
  theme: 'ubc-theme',
  fontSize: 'ubc-font-size'
};

function applyTheme(theme) {
  root.dataset.theme = theme;
  themeToggle.textContent = theme === 'dark' ? 'Light mode' : 'Dark mode';
  localStorage.setItem(STORAGE_KEYS.theme, theme);
}

function applyFontSize(size) {
  root.dataset.fontSize = size;
  localStorage.setItem(STORAGE_KEYS.fontSize, size);
}

function hydratePreferences() {
  const savedTheme = localStorage.getItem(STORAGE_KEYS.theme);
  const savedFont = localStorage.getItem(STORAGE_KEYS.fontSize);
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  applyTheme(savedTheme || (prefersDark ? 'dark' : 'light'));
  applyFontSize(savedFont || 'normal');
}

hydratePreferences();

themeToggle.addEventListener('click', () => {
  applyTheme(root.dataset.theme === 'dark' ? 'light' : 'dark');
});

fontSmaller.addEventListener('click', () => applyFontSize('small'));
fontReset.addEventListener('click', () => applyFontSize('normal'));
fontLarger.addEventListener('click', () => applyFontSize('large'));

if (navToggle) {
  navToggle.addEventListener('click', () => {
    const expanded = navToggle.getAttribute('aria-expanded') === 'true';
    navToggle.setAttribute('aria-expanded', String(!expanded));
    siteNav.classList.toggle('is-open');
  });

  siteNav.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      navToggle.setAttribute('aria-expanded', 'false');
      siteNav.classList.remove('is-open');
    });
  });
}

filterButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const filter = button.dataset.filter;
    filterButtons.forEach((btn) => btn.classList.remove('is-active'));
    button.classList.add('is-active');

    sessionCards.forEach((card) => {
      const category = card.dataset.category;
      const show = filter === 'all' || category === filter;
      card.hidden = !show;
    });
  });
});

async function loadWeather() {
  const container = document.getElementById('weather-output');
  try {
    const endpoint = 'https://api.open-meteo.com/v1/forecast?latitude=51.0154&longitude=-3.1027&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m&hourly=temperature_2m&forecast_days=1';
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);
    const response = await fetch(endpoint, { signal: controller.signal });
    clearTimeout(timeout);
    if (!response.ok) throw new Error('Weather request failed');
    const data = await response.json();

    const current = data.current || {};
    const hourlyTimes = data.hourly?.time?.slice(0, 3) || [];
    const hourlyTemps = data.hourly?.temperature_2m?.slice(0, 3) || [];

    container.innerHTML = `
      <div class="weather-main">
        <div>
          <p class="weather-temp">${Math.round(current.temperature_2m ?? 0)}°C</p>
          <p class="weather-meta">Feels like ${Math.round(current.apparent_temperature ?? 0)}°C · wind ${Math.round(current.wind_speed_10m ?? 0)} km/h</p>
        </div>
        <div>
          <p class="weather-meta"><strong>Taunton</strong><br/>Live conditions via API</p>
        </div>
      </div>
      <div class="weather-list">
        ${hourlyTimes.map((time, index) => {
          const hour = new Date(time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          return `<article><strong>${hour}</strong><span>${Math.round(hourlyTemps[index] ?? 0)}°C</span></article>`;
        }).join('')}
      </div>
    `;
  } catch (error) {
    container.innerHTML = '<p class="loading">Weather data is unavailable right now, but the API component is configured and can be tested with an internet connection.</p>';
  }
}

loadWeather();

contactForm?.addEventListener('submit', (event) => {
  event.preventDefault();

  const formData = new FormData(contactForm);
  const name = String(formData.get('name') || '').trim();
  const email = String(formData.get('email') || '').trim();
  const interest = String(formData.get('interest') || '').trim();
  const message = String(formData.get('message') || '').trim();

  if (!name || !email || !message) {
    feedback.textContent = 'Please complete your name, email and message before continuing.';
    return;
  }

  const subject = encodeURIComponent(`Website enquiry - ${interest}`);
  const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\nInterest: ${interest}\n\nMessage:\n${message}`);
  const mailto = `mailto:info@unicornbadminton.club?subject=${subject}&body=${body}`;

  feedback.textContent = 'Your email app should open now with the enquiry pre-filled.';
  window.location.href = mailto;
});

// Commit 3 marker: accessibility controls and session filters preserved in local storage
